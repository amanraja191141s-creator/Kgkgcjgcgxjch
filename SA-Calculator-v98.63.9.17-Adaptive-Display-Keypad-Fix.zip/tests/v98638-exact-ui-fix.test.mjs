import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const read = p => fs.readFileSync(path.join(root,p),'utf8');
test('v98.63.8 picker preserves a safe selected-option fallback while showing all catalog entries',()=>{
 const js=read('assets/js/app.js');
 assert.match(js,/function selectedOptionIndex\(select, entries\)/);
 assert.match(js,/const selectedIndex = selectedOptionIndex\(select, entries\)/);
 assert.match(js,/Every enabled option is present on first open/);
 assert.doesNotMatch(js,/revealAlternatives/);
 assert.match(js,/highlighted = selectedOptionIndex\(select, optionEntries\(select\)\)/);
});
test('v98.63.8 compact keypad overrides legacy high-specificity sizing and caps display at 700px',()=>{
 const css=read('assets/css/app.css');
 assert.match(css,/#screen-calc\.active > \.calc-display/);
 assert.match(css,/width:min\(100%,700px\)!important/);
 assert.match(css,/#screen-calc\.active > \.main-keypad > button\.key-btn/);
 assert.match(css,/width:76%!important;height:74%!important/);
});
test('v98.63.8 currency and unit native selects are hidden and custom picker rows stay vertical',()=>{
 const css=read('assets/css/app.css');
 assert.match(css,/select\.sumaire-select-native/);
 assert.match(css,/body \.sumaire-picker-backdrop \.sumaire-picker-options/);
 assert.match(css,/flex-direction:column!important/);
 assert.match(css,/body \.sumaire-picker-backdrop \.sumaire-picker-option/);
});
test('v98.63.8 CSS is part of the actual Android production build and cache is migrated',()=>{
 const build=read('scripts/prepare-android-web.mjs');
 const html=read('index.html');
 const sw=read('service-worker.js');
 assert.match(build,/assets\/css\/app\.css/);
 assert.match(html,/assets\/css\/app\.css/);
 assert.match(sw,/sa-calculator-v98-63-10-clean-runtime-v9863917/);
});
